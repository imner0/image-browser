# stable-diffusion-webui-images-browser

This an extension for [stable-diffusion-webui](https://github.com/AUTOMATIC1111/stable-diffusion-webui)

This an images browser for browsing past generated pictures， view their generated infomations，send the prompt to txt2img or img2img， collect images to your "faveries" fold, delete the images you no longer need， and you can also browse images in any folds in your computer  
![image](https://s6.jpg.cm/2022/10/24/PJjuZt.png)

go to the directory \<stable-diffusion-webui project path\>/extensions and run command to install:

`git clone https://github.com/yfszzx/stable-diffusion-webui-images-browser `

and restart your stable-diffusion-webui, then you can see the new tab "Images Browser"

[See here for more install details](https://github.com/AUTOMATIC1111/stable-diffusion-webui/wiki/Extensions)
